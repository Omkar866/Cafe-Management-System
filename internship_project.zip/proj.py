from tkinter import *
from datetime import datetime
from tkinter import messagebox
import requests
import pymongo

root=Tk()
myclient = pymongo.MongoClient('localhost', 27017) #connecting mongodb server
window_width=root.winfo_screenwidth()-210
window_height=root.winfo_screenheight()-200
root.geometry(f'{window_width}x{window_height}+{int(root.winfo_screenwidth()/2-window_width/2)}+{int(root.winfo_screenheight()/2-window_height/2)}')
#root.maxsize(window_width,window_height)
root.title("Omkar's Cafe")


Title_Frame=Frame(root,borderwidth=6,relief=GROOVE,bg="#e60000")

Label(Title_Frame,text="Omkar's Cafe".center(153),bg="#e60000",fg='White',padx=3,pady=14,font="American 20 bold").grid(row=0,column=0,columnspan=3,sticky='e')


Menu_frame=Frame(root,borderwidth=7,relief=RIDGE,bg="red")
Veg_Food_Frame=LabelFrame(Menu_frame,text="Veg",borderwidth=5,relief=RIDGE,pady=25,padx=14,font="American 15 bold")
Drink_frame=LabelFrame(Menu_frame,text="Drinks",borderwidth=5,relief=RIDGE,pady=25,padx=14,font="American 15 bold")
Non_Veg_Food_Frame=LabelFrame(Menu_frame,text="Non Veg",borderwidth=5,relief=RIDGE,pady=25,padx=10,font="American 15 bold")
Total_Frame=Frame(root,bg="#e60000",borderwidth=8,relief=RIDGE,padx=19,pady=19)
Calc_Bill_Frame=Frame(root,borderwidth=8,bg="#e60000",relief=RIDGE)

Calculator_frame=Frame(Calc_Bill_Frame)
Bill_frame=Frame(Calc_Bill_Frame,bg="#b30000",borderwidth=4,relief=RIDGE)
Button_Frame=Frame(Calc_Bill_Frame,bg="#b30000",relief=RIDGE,borderwidth=5)



e_burger=StringVar()
e_french_fries=StringVar()
e_sandwich=StringVar()
e_momos=StringVar()
e_maggi=StringVar()
e_pizza=StringVar()
e_taco=StringVar()
e_veg_rolls=StringVar()
e_pasta=StringVar()

e_hot_coffee=StringVar()
e_coffee=StringVar()
e_black_tea=StringVar()
e_fanta=StringVar()
e_jaljeera=StringVar()
e_roohfza=StringVar()
e_coca_cola=StringVar()
e_limca=StringVar()
e_sprite=StringVar()

e_egg_burger=StringVar()
e_chicken_pizza=StringVar()
e_chicken_fries=StringVar()
e_tandoori=StringVar()
e_chicken_65=StringVar()
e_chicken_pasta=StringVar()
e_non_veg_maggi=StringVar()
e_chocolate=StringVar()
e_egg_sandwich=StringVar()

t_food=StringVar()
t_drinks=StringVar()
t_cake=StringVar()
t_total=StringVar()
t_service=StringVar()
t_grand_total=StringVar()

l_burger=IntVar()
l_french_fries=IntVar()
l_sandwich=IntVar()
l_momos=IntVar()
l_maggi=IntVar()
l_pizza=IntVar()
l_taco=IntVar()
l_veg_rolls=IntVar()
l_pasta=IntVar()

l_hot_coffee=IntVar()
l_coffee=IntVar()
l_black_tea=IntVar()
l_fanta=IntVar()
l_jaljeera=IntVar()
l_roohfza=IntVar()
l_coca_cola=IntVar()
l_limca=IntVar()
l_sprite=IntVar()

l_egg_burger=IntVar()
l_apple=IntVar()
l_chicken_fries=IntVar()
l_tandoori=IntVar()
l_chicken_65=IntVar()
l_chicken_pasta=IntVar()
l_non_veg_maggi=IntVar()
l_chicken_soup=IntVar()
l_egg_sandwich=IntVar()


receipt_txt=StringVar()
calc_answer_txt=StringVar()

cart=[]

def send():

    def send_fn():
        if get_customer_details.mob_no=='':
            messagebox.showerror("Error","Invalid Phone number")
        else:
            msg=Textarea1.get("1.0",END)
            number=(get_customer_details.mob_no,)
            auth="RgKlMswNxVEmfoHvT0k8b2utZiDhXypz4AcnFqjBaI5Jde61SLRiucmZMJ2DjPSXzAOkfesvlHaCIrEn"
            url="https://www.fast2sms.com/dev/bulkV2"
            params={
                'authorization':auth,
                'message':msg,
                'numbers':number,
                'route':'q',
                'language':'english',
                'flash':'0'

            }

            response=requests.get(url,params=params)
            dic=response.json()
            result=dic.get('return')

            

            if result ==True:
                messagebox.showinfo("Sent Successfully","Sent Successfully")
            else:
                messagebox.showerror("Error",dic.get('message'))


    if cart==[] or Textarea.get("1.0",END)=="":
        messagebox.showwarning("Error","Fill the cart and generate receipt to send bill")
    else:
        new_win=Toplevel()
        new_win.geometry("500x500")
        #new_win.maxsize(500,500)
        new_win.option_add("*background","red3")
        new_win.config(bg="red3")
        label1=Label(new_win,text="Bill",font="Monospace 30 bold",padx=220)
        Textarea1=Text(new_win,font="Monospace 14 bold",height=15,width=43,borderwidth=3,bg="white")
        scrollbar=Scrollbar(new_win,orient='vertical',command=Textarea1.yview)
        Textarea1['yscrollcommand']=scrollbar.set
        label1.grid(row=0,column=0,columnspan=2)
        Textarea1.grid(row=1,column=0)
        scrollbar.grid(row=1,column=1,ipadx=4,ipady=144)

        send_sms=Button(new_win,text="Send SMS",command=send_fn,font="American 15 bold",fg="white",borderwidth=5,relief=SUNKEN)
        send_sms.grid(row=2,column=0,pady=40,ipadx=20,ipady=10)

        Textarea1.delete("1.0",END)
        Textarea1.insert(INSERT,Textarea.get("1.0","5.0"))
        if Cost_of_Veg_Food_Entry.get()!='0':
            Textarea1.insert(INSERT,"Cost of Veg Food \t\t\t"+str(Cost_of_Veg_Food_Entry.get()+"\n"))
        if Cost_of_Drinks_Entry.get()!='0':
            Textarea1.insert(INSERT,"Cost of Drinks \t\t\t"+str(Cost_of_Drinks_Entry.get()+"\n"))
        if Cost_of_Non_veg_Food_Entry.get()!='0':
            Textarea1.insert(INSERT,"Cost of Non Veg Food \t\t\t"+str(Cost_of_Non_veg_Food_Entry.get()+"\n"))
        Textarea1.insert(INSERT,"Total \t\t\t"+str(Sub_Total_Entry.get())+"\n")
        Textarea1.insert(INSERT,"Service Tax \t\t\t"+str(Service_Tax_Entry.get())+"\n")
        Textarea1.insert(INSERT,"Grand Total \t\t\t"+str(Total_Cost_Entry.get())+"\n")




def reset():
    cbns=[l_burger,l_french_fries,l_sandwich,l_momos,l_maggi,l_pizza,l_taco,l_veg_rolls,l_pasta,l_hot_coffee,l_coffee,l_black_tea,l_fanta,l_jaljeera,l_roohfza,l_coca_cola,l_limca,l_sprite,l_egg_burger,l_apple,l_chicken_fries,l_tandoori,l_chicken_65,l_chicken_pasta,l_non_veg_maggi,l_chicken_soup,l_egg_sandwich]
        
    for item in cbns:
        item.set(0)

    ewvs=[e_burger,e_french_fries,e_sandwich,e_momos,e_maggi,e_pizza,e_taco,e_veg_rolls,e_pasta
,e_hot_coffee,e_coffee,e_black_tea,e_fanta,e_jaljeera,e_roohfza,e_coca_cola,e_limca,e_sprite
,e_egg_burger,e_chicken_pizza,e_chicken_fries,e_tandoori,e_chicken_65,e_chicken_pasta,e_non_veg_maggi,e_chocolate,e_egg_sandwich]

    ews=[Burger_Entry,French_Fries_Entry,Sandwich_Entry,Momos_Entry,Maggi_Entry,Pizza_Entry,Taco_Entry,Veg_Rolls_Entry,Pasta_Entry,Hot_Coffee_Entry,Coffee_Entry,Black_Tea_Entry,Fanta_Entry,Hot_chocolate__Entry,Maaza_Entry,Coca_Cola_Entry,Milk_Entry,Sprite_Entry,Egg_Burger_Entry,Chicken_Pizza_Entry,Chicken_Fries_Entry,Tandoori_Entry,Chicken_65_Entry,Chicken_Pasta_Entry,Non_Veg_Maggi_Entry,Chicken_Soupt_Entry,Egg_Sandwich__Entry]

    for i in range(len(ewvs)):
        ews[i].configure(state=NORMAL)
        ewvs[i].set('0')
        ews[i].configure(state=DISABLED)



    cart.clear()

    Textarea.config(state=NORMAL)
    Textarea.delete(1.0,END)
    

    bottom_entry=[t_food,t_drinks,t_cake,t_total,t_service,t_grand_total]
    for var in bottom_entry:
        var.set('')    

    Answer.config(state=NORMAL)
    calc_answer_txt.set('')
    Answer.config(state=DISABLED)
    

    root.update_idletasks()




def get_bill_no():
    dbnames=myclient.list_database_names()
    if 'Cafe_Management_System' not in dbnames:
        mydb= myclient['Cafe_Management_System']
        main_collection=mydb['Main_db']

        return 1
    
    else:
        mydb= myclient['Cafe_Management_System']
        main_collection=mydb['Main_db']

        bill_no=0
        for x in main_collection.find():
            bill_no+=1
        return bill_no+1

        

        


def save_fn():
    if cart==[] or Textarea.get("1.0",END)=="":
        messagebox.showwarning("Error","Fill the cart and generate receipt to save bill")
    else:
        bill_no=get_bill_no()
        
        data={
            'Bill_No':bill_no,
            'Customer_Name':get_customer_details.name,
            'Mobile_No':get_customer_details.mob_no,
            'Date':datetime.now().strftime("%d %m %Y")
        }
        mydb= myclient['Cafe_Management_System']
        main_collection=mydb['Main_db']
        main_collection.insert_one(data)

        bill_collection=mydb['Bill_No_'+str(get_bill_no()-1)]
        for item in cart:
            bill_collection.insert_one({'Name':item[0],'Quantity':item[1][1],'Price':item[1][0]*item[1][1]})

        bill_collection.insert_one({'Name':'Cost of veg food','Price':Cost_of_Veg_Food_Entry.get()})
        bill_collection.insert_one({'Name':'Cost of non veg food','Price':Cost_of_Non_veg_Food_Entry.get()})
        bill_collection.insert_one({'Name':'Cost of drinks','Price':Cost_of_Drinks_Entry.get()})
        bill_collection.insert_one({'Name':'Sub Total','Price':Sub_Total_Entry.get()})
        bill_collection.insert_one({'Name':'Service Tax','Price':Service_Tax_Entry.get()})
        bill_collection.insert_one({'Name':'Total Cost','Price':Total_Cost_Entry.get()})


        messagebox.showinfo("Saved","Bill Saved successfully")



def get_customer_details():

    new_window=Toplevel(root)
    new_window.configure(bg='#e60000')
    new_window.option_add("*background","#e60000")
    new_window.geometry("700x400")
    new_window.title("Customer name")

    name=StringVar()
    mob_no=StringVar()

    cust_name=Label(new_window,text="Enter customer name",font="Arail 20 bold",pady=30)
    cust_name.grid(row=0,column=0)
    Cust_name_entry_box=Entry(new_window,width=20,font="Arial 20 bold",bg="white",textvariable=name,borderwidth=7,relief=SUNKEN)
    Cust_name_entry_box.grid(row=1,column=0)
    cust_mob=Label(new_window,text="Enter customer mobile number",font="Arail 20 bold",pady=20,padx=170)
    cust_mob.grid(row=2,column=0)
    Cust_mob_entry_box=Entry(new_window,width=20,font="Arial 20 bold",bg="white",textvariable=mob_no,borderwidth=7,relief=SUNKEN)
    Cust_mob_entry_box.grid(row=3,column=0,pady=20)


    def btn_fn():
        setattr(get_customer_details,"name",name.get())
        setattr(get_customer_details,"mob_no",mob_no.get())
        new_window.destroy()

    Button(new_window,text="Submit",bg='blue',fg='white',font="bold",command=btn_fn,borderwidth=5,relief=SUNKEN).grid(row=4,column=0,ipadx=20,ipady=10,sticky=S,pady=20)

    new_window.mainloop()
    
    



def submit():
    

    cart.clear()

    Veg_Food=['Burger','French_Fries','Sandwich','Momos','Veg Maggi','Pizza','Taco','Veg_Rolls','Pasta']
    Veg_Food_Price=[159,110,60,95,40,210,159,70,100]
    Veg_Food_Quantity=[int(item.get()) for item in Food_entry_list]


    dict_veg_food={Veg_Food[i]:[Veg_Food_Price[i],Veg_Food_Quantity[i]] for i in range(len(Veg_Food))}

    dict_veg_food=dict(filter(lambda pair:pair[1][1]>0,dict_veg_food.items()))
    
    veg_food_cost=[dict_veg_food[key][0]*dict_veg_food[key][1] for key in dict_veg_food.keys()]
    Cost_of_Veg_Food_Entry.config(state=NORMAL)
    Cost_of_Veg_Food_Entry.delete(0,END)
    Cost_of_Veg_Food_Entry.insert(0,sum(veg_food_cost))
    #Cost_of_Non_veg_Food_Entry.config(state=DISABLED)

    

    
    Drinks=['Hot_Coffee','Coffee','Black Tea','Fanta','Hot chocolate','Maaza','Coca_Cola','Limca','Sprite']
    Drinks_Price=[50,60,30,50,200,70,40,50,60]
    Drinks_Quantity=[int(item.get()) for item in Drinks_entry_list]

    dict_drinks={Drinks[i]:[Drinks_Price[i],Drinks_Quantity[i]] for i in range(len(Drinks))}

    dict_drinks=dict(filter(lambda pair:pair[1][1]>0,dict_drinks.items()))
    
    drinks_cost=[dict_drinks[key][0]*dict_drinks[key][1] for key in dict_drinks.keys()]
    Cost_of_Drinks_Entry.config(state=NORMAL)
    Cost_of_Drinks_Entry.delete(0,END)
    Cost_of_Drinks_Entry.insert(0,sum(drinks_cost))
    #Cost_of_Veg_Food_Entry.config(state=DISABLED)

    

    
    Non_Veg_Food=['Egg Burger','Chicken Pizza','Chicken Fries','Tandoori','Chicken 65','Chicken Pasta','Non Veg Maggi','Chicken Soup','Egg Sandwich']
    Non_Veg_Food_Price=[210,325,175,309,90,150,70,75,45]
    Non_Veg_Food_Quantity=[int(item.get()) for item in Cake_entry_list]

    dict_non_veg={Non_Veg_Food[i]:[Non_Veg_Food_Price[i],Non_Veg_Food_Quantity[i]] for i in range(len(Non_Veg_Food))}

    dict_non_veg=dict(filter(lambda pair:pair[1][1]>0,dict_non_veg.items()))
    
    non_veg_food_cost=[dict_non_veg[key][0]*dict_non_veg[key][1] for key in dict_non_veg.keys()]

    Cost_of_Non_veg_Food_Entry.config(state=NORMAL)
    Cost_of_Non_veg_Food_Entry.delete(0,END)

    Cost_of_Non_veg_Food_Entry.insert(0,sum(non_veg_food_cost))
    #Cost_of_Drinks_Entry.config(state=DISABLED)


    

    sum_total=sum((sum(veg_food_cost),sum(drinks_cost),sum(non_veg_food_cost)))
    Sub_Total_Entry.config(state=NORMAL)
    Sub_Total_Entry.delete(0,END)
    Sub_Total_Entry.insert(0,sum_total)
    #Sub_Total_Entry.config(state=DISABLED)
    

    service_tax=round((sum_total*0.4)*(14/100),2)

    Service_Tax_Entry.config(state=NORMAL)
    Service_Tax_Entry.delete(0,END)
    Service_Tax_Entry.insert(0,service_tax)
    #Service_Tax_Entry.config(state=DISABLED)

    Total_Cost_Entry.config(state=NORMAL)
    Total_Cost_Entry.delete(0,END)
    Total_Cost_Entry.insert(0,sum_total+service_tax)
    #Total_Cost_Entry.config(state=DISABLED)

    temp={**dict_veg_food,**dict_drinks,**dict_non_veg}
    cart.extend([[key,temp[key]] for key in temp.keys()])
    cart.sort(key=lambda x:-x[1][0]*x[1][1])

    
    get_customer_details()
    


def receipt():
    if cart==[]:
        messagebox.showerror("Empty cart","Please add some items in cart")

    else:
        Textarea.delete(1.0,END)
        Textarea.insert(INSERT,"Omkar's Cafe\n".rjust(40))
        date=datetime.now()
        Textarea.insert(INSERT,"Date :-"+date.strftime("%d/%m/%y")+"\t\t\t")
        Textarea.insert(INSERT,"Time :-"+date.strftime("%H:%M:%S")+"\n")
        Textarea.insert(INSERT,"Bill N.o :-"+str(get_bill_no())+"\n")
        Textarea.insert(INSERT,"Customer Name :- \t"+get_customer_details.name+"\n")
        Textarea.insert(INSERT,"Customer Mobile N.o :- \t"+get_customer_details.mob_no+"\n\n\n")
        Textarea.insert(INSERT,"Item\t\t"+"Quantity\t\t"+"Price"+"\n")
        for item in cart:
            Textarea.insert(INSERT,str(item[0])+"\t\t"+str(item[1][1])+"\t\t"+str(item[1][0]*item[1][1])+"\t\t"+"\n")
        Textarea.insert(INSERT,"-"*67+"\n"*4)
        temp_list=[cart[i][1][0]*cart[i][1][1] for i in range(len(cart))]
        temp_dic={key:value for key,value in zip(('cost of veg food','cost of drinks','cost of non veg food'),(Cost_of_Veg_Food_Entry.get(),Cost_of_Drinks_Entry.get(),Cost_of_Non_veg_Food_Entry.get())) if value!='0'}
        for key in temp_dic.keys():
            Textarea.insert(INSERT,key+"\t\t\t"+temp_dic[key]+"\n")
        
        
        Textarea.insert(INSERT,"Total"+"\t\t\t"+str(sum(temp_list))+"\n")
        Textarea.insert(INSERT,"Service Tax"+"\t\t\t"+str(round((sum(temp_list)*5.8/100),2))+"\n")
        Textarea.insert(INSERT,"Grand Total"+"\t\t\t"+str(sum(temp_list)+sum(temp_list)/10)+"\n")
        Textarea.insert(INSERT,"\n\nThanks for visiting\n\n")




def general_fn(checkbutton_variable,entry_widget):
    if checkbutton_variable.get()==1:
        entry_widget.config(state=NORMAL)
        entry_widget.delete(0,END)
        entry_widget.focus()
    else:
        entry_widget.delete(0,END)
        entry_widget.insert(0,0)
        entry_widget.config(state=DISABLED)
        
        entry_widget.update_idletasks()




Burger_Entry=Entry(Veg_Food_Frame,state=DISABLED,textvariable=e_burger,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
French_Fries_Entry=Entry(Veg_Food_Frame,state=DISABLED,textvariable=e_french_fries,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
Sandwich_Entry=Entry(Veg_Food_Frame,state=DISABLED,textvariable=e_sandwich,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
Momos_Entry=Entry(Veg_Food_Frame,state=DISABLED,textvariable=e_momos,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
Maggi_Entry=Entry(Veg_Food_Frame,state=DISABLED,textvariable=e_maggi,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
Pizza_Entry=Entry(Veg_Food_Frame,state=DISABLED,textvariable=e_pizza,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
Taco_Entry=Entry(Veg_Food_Frame,state=DISABLED,textvariable=e_taco,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
Veg_Rolls_Entry=Entry(Veg_Food_Frame,state=DISABLED,textvariable=e_veg_rolls,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
Pasta_Entry=Entry(Veg_Food_Frame,state=DISABLED,textvariable=e_pasta,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)



Burger=Checkbutton(Veg_Food_Frame,text="Burger",font="American 14 bold",justify="left",var=l_burger,command=lambda:general_fn(l_burger,Burger_Entry),pady=2)
French_Fries=Checkbutton(Veg_Food_Frame,text="French Fries",font="American 14 bold",justify="left",command=lambda:general_fn(l_french_fries,French_Fries_Entry),var=l_french_fries,pady=2)
Sandwich=Checkbutton(Veg_Food_Frame,text="Sandwich",font="American 14 bold",justify="left",command=lambda:general_fn(l_sandwich,Sandwich_Entry),var=l_sandwich,pady=2)
Momos=Checkbutton(Veg_Food_Frame,text="Momos",font="American 14 bold",justify="left",command=lambda:general_fn(l_momos,Momos_Entry),var=l_momos,pady=2)
Maggi=Checkbutton(Veg_Food_Frame,text="Maggi",font="American 14 bold",justify="left",command=lambda:general_fn(l_maggi,Maggi_Entry),var=l_maggi,pady=2)
Pizza=Checkbutton(Veg_Food_Frame,text="Pizza",font="American 14 bold",justify="left",command=lambda:general_fn(l_pizza,Pizza_Entry),var=l_pizza,pady=2)
Taco=Checkbutton(Veg_Food_Frame,text="Taco",font="American 14 bold",justify="left",command=lambda:general_fn(l_taco,Taco_Entry),var=l_taco,pady=2)
Veg_Rolls=Checkbutton(Veg_Food_Frame,text="Veg Rolls",font="American 14 bold",justify="left",command=lambda:general_fn(l_veg_rolls,Veg_Rolls_Entry),var=l_veg_rolls,pady=2)
Pasta=Checkbutton(Veg_Food_Frame,text="Pasta",font="American 14 bold",justify="left",command=lambda:general_fn(l_pasta,Pasta_Entry),var=l_pasta,pady=2)

Food_list=[Burger,French_Fries,Sandwich,Momos,Maggi,Pizza,Taco,Veg_Rolls,Pasta]
for i in range(1,len(Food_list)+1):
    Food_list[i-1].grid(row=i,column=0,sticky="w")



Food_entry_list=[Burger_Entry,French_Fries_Entry,Sandwich_Entry,Momos_Entry,Maggi_Entry,Pizza_Entry,Taco_Entry,Veg_Rolls_Entry,Pasta_Entry]

for i in range(1,len(Food_entry_list)+1):
    Food_entry_list[i-1].grid(row=i,column=1,padx=10)
    Food_entry_list[i-1].configure(state=NORMAL)
    Food_entry_list[i-1].insert(0,'0')
    Food_entry_list[i-1].configure(state=DISABLED)
    
    
Hot_Coffee_Entry=Entry(Drink_frame,textvariable=e_hot_coffee,borderwidth=5,state=DISABLED,relief=SUNKEN,font="American 15 bold",width=5)
Coffee_Entry=Entry(Drink_frame,textvariable=e_coffee,borderwidth=5,state=DISABLED,relief=SUNKEN,font="American 15 bold",width=5)
Black_Tea_Entry=Entry(Drink_frame,textvariable=e_black_tea,borderwidth=5,state=DISABLED,relief=SUNKEN,font="American 15 bold",width=5)
Fanta_Entry=Entry(Drink_frame,textvariable=e_fanta,borderwidth=5,state=DISABLED,relief=SUNKEN,font="American 15 bold",width=5)
Hot_chocolate__Entry=Entry(Drink_frame,textvariable=e_jaljeera,borderwidth=5,state=DISABLED,relief=SUNKEN,font="American 15 bold",width=5)
Maaza_Entry=Entry(Drink_frame,textvariable=e_roohfza,borderwidth=5,state=DISABLED,relief=SUNKEN,font="American 15 bold",width=5)
Coca_Cola_Entry=Entry(Drink_frame,textvariable=e_coca_cola,borderwidth=5,state=DISABLED,relief=SUNKEN,font="American 15 bold",width=5)
Milk_Entry=Entry(Drink_frame,textvariable=e_limca,borderwidth=5,state=DISABLED,relief=SUNKEN,font="American 15 bold",width=5)
Sprite_Entry=Entry(Drink_frame,textvariable=e_sprite,borderwidth=5,state=DISABLED,relief=SUNKEN,font="American 15 bold",width=5)


Hot_Coffee=Checkbutton(Drink_frame,text="Hot Coffee",font="American 14 bold",justify="left",command=lambda:general_fn(l_hot_coffee,Hot_Coffee_Entry),var=l_hot_coffee,pady=2)
Coffee=Checkbutton(Drink_frame,text="Cold Coffee",font="American 14 bold",justify="left",command=lambda:general_fn(l_coffee,Coffee_Entry),var=l_coffee,pady=2)
Black_Tea=Checkbutton(Drink_frame,text="Black Tea",font="American 14 bold",justify="left",command=lambda:general_fn(l_black_tea,Black_Tea_Entry),var=l_black_tea,pady=2)
Fanta=Checkbutton(Drink_frame,text="Fanta",font="American 14 bold",justify="left",command=lambda:general_fn(l_fanta,Fanta_Entry),var=l_fanta,pady=2)
Hot_chocolate=Checkbutton(Drink_frame,text="Hot Chocolate",font="American 14 bold",justify="left",command=lambda:general_fn(l_jaljeera,Hot_chocolate__Entry),var=l_jaljeera,pady=2)
Maaza=Checkbutton(Drink_frame,text="Maaza",font="American 14 bold",justify="left",command=lambda:general_fn(l_roohfza,Maaza_Entry),var=l_roohfza,pady=2)
Coca_Cola=Checkbutton(Drink_frame,text="Coca Cola",font="American 14 bold",justify="left",command=lambda:general_fn(l_coca_cola,Coca_Cola_Entry),var=l_coca_cola,pady=2)
Limca=Checkbutton(Drink_frame,text="Limca",font="American 14 bold",justify="left",command=lambda:general_fn(l_limca,Milk_Entry),var=l_limca,pady=2)
Sprite=Checkbutton(Drink_frame,text="Sprite",font="American 14 bold",justify="left",command=lambda:general_fn(l_sprite,Sprite_Entry),var=l_sprite,pady=2)

Drink_list=[Hot_Coffee,Coffee,Black_Tea,Fanta,Hot_chocolate,Maaza,Coca_Cola,Limca,Sprite]

for i in range(1,len(Drink_list)+1):
    Drink_list[i-1].grid(row=i,sticky="w")




Drinks_entry_list=[Hot_Coffee_Entry,Coffee_Entry,Black_Tea_Entry,Fanta_Entry,Hot_chocolate__Entry,Maaza_Entry,  Coca_Cola_Entry,Milk_Entry,Sprite_Entry]

for i in range(1,len(Drinks_entry_list)+1):
    Drinks_entry_list[i-1].grid(row=i,column=1,padx=10)
    Drinks_entry_list[i-1].grid(row=i,column=1,padx=10)
    Drinks_entry_list[i-1].configure(state=NORMAL)
    Drinks_entry_list[i-1].insert(0,'0')
    Drinks_entry_list[i-1].configure(state=DISABLED)



Egg_Burger_Entry=Entry(Non_Veg_Food_Frame,textvariable=e_egg_burger,state=DISABLED,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
Chicken_Pizza_Entry=Entry(Non_Veg_Food_Frame,textvariable=e_chicken_pizza,state=DISABLED,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
Chicken_Fries_Entry=Entry(Non_Veg_Food_Frame,textvariable=e_chicken_fries,state=DISABLED,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
Tandoori_Entry=Entry(Non_Veg_Food_Frame,textvariable=e_tandoori,state=DISABLED,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
Chicken_65_Entry=Entry(Non_Veg_Food_Frame,textvariable=e_chicken_65,state=DISABLED,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
Chicken_Pasta_Entry=Entry(Non_Veg_Food_Frame,textvariable=e_chicken_pasta,state=DISABLED,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
Non_Veg_Maggi_Entry=Entry(Non_Veg_Food_Frame,textvariable=e_non_veg_maggi,state=DISABLED,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
Chicken_Soupt_Entry=Entry(Non_Veg_Food_Frame,textvariable=e_chocolate,state=DISABLED,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)
Egg_Sandwich__Entry=Entry(Non_Veg_Food_Frame,textvariable=e_egg_sandwich,state=DISABLED,borderwidth=5,relief=SUNKEN,font="American 15 bold",width=5)






Egg_Burger=Checkbutton(Non_Veg_Food_Frame,text="Egg Burger",font="American 14 bold",justify="left",command=lambda:general_fn(l_egg_burger,Egg_Burger_Entry),var=l_egg_burger,pady=2)
Apple=Checkbutton(Non_Veg_Food_Frame,text="Chicken Pizza",font="American 14 bold",justify="left",command=lambda:general_fn(l_apple,Chicken_Pizza_Entry),var=l_apple,pady=2)
Chicken_Fries=Checkbutton(Non_Veg_Food_Frame,text="Chicken Fries",font="American 14 bold",justify="left",command=lambda:general_fn(l_chicken_fries,Chicken_Fries_Entry),var=l_chicken_fries,pady=2)
Tandoori=Checkbutton(Non_Veg_Food_Frame,text="Tandoori",font="American 14 bold",justify="left",command=lambda:general_fn(l_tandoori,Tandoori_Entry),var=l_tandoori,pady=2)
Chicken_65=Checkbutton(Non_Veg_Food_Frame,text="Chicken 65",font="American 14 bold",justify="left",command=lambda:general_fn(l_chicken_65,Chicken_65_Entry),var=l_chicken_65,pady=2)
Chicken_Pasta=Checkbutton(Non_Veg_Food_Frame,text="Chicken Pasta",font="American 14 bold",justify="left",command=lambda:general_fn(l_chicken_pasta,Chicken_Pasta_Entry),var=l_chicken_pasta,pady=2)
Non_Veg_Maggi=Checkbutton(Non_Veg_Food_Frame,text="Maggi",font="American 14 bold",justify="left",command=lambda:general_fn(l_non_veg_maggi,Non_Veg_Maggi_Entry),var=l_non_veg_maggi,pady=2)
Chicken_Soup=Checkbutton(Non_Veg_Food_Frame,text="Chicken Soup",font="American 14 bold",justify="left",command=lambda:general_fn(l_chicken_soup,Chicken_Soupt_Entry),var=l_chicken_soup,pady=2)
Egg_Sandwich=Checkbutton(Non_Veg_Food_Frame,text="Egg Sandwich",font="American 14 bold",justify="left",command=lambda:general_fn(l_egg_sandwich,Egg_Sandwich__Entry),var=l_egg_sandwich,pady=2)

Cake_list=[Egg_Burger,Apple,Chicken_Fries,Tandoori,Chicken_65,Chicken_Pasta,Non_Veg_Maggi,Chicken_Soup,Egg_Sandwich]
for i in range(1,len(Cake_list)+1):
    Cake_list[i-1].grid(row=i,column=0,sticky="w")



Cake_entry_list=[Egg_Burger_Entry,Chicken_Pizza_Entry,Chicken_Fries_Entry,Tandoori_Entry,Chicken_65_Entry,Chicken_Pasta_Entry,Non_Veg_Maggi_Entry,Chicken_Soupt_Entry,Egg_Sandwich__Entry]
for i in range(1,len(Cake_entry_list)+1):
    Cake_entry_list[i-1].grid(row=i,column=1,padx=10)
    Cake_entry_list[i-1].grid(row=i,column=1,padx=10)
    Cake_entry_list[i-1].configure(state=NORMAL)
    Cake_entry_list[i-1].insert(0,'0')
    Cake_entry_list[i-1].configure(state=DISABLED)




Cost_of_Veg_Food=Label(Total_Frame,text="Cost of Veg Food",bg="#e60000",font="American 15 bold",fg="white")
Cost_of_Drinks=Label(Total_Frame,text="Cost of Drinks",bg="#e60000",font="American 15 bold",fg="white",pady=14)
Cost_of_Non_veg_Food=Label(Total_Frame,text="Cost of Non Veg Food",bg="#e60000",font="American 15 bold",fg="white")
Sub_Total=Label(Total_Frame,text="Sub Total",bg="#e60000",font="American 15 bold",fg="white")
Service_Tax=Label(Total_Frame,text="Service Tax",bg="#e60000",font="American 15 bold",fg="white",pady=14)
Total_Cost=Label(Total_Frame,text="Total Cost",bg="#e60000",font="American 15 bold",fg="white")

Cost_of_Veg_Food_Entry=Entry(Total_Frame,textvariable=t_drinks,font="American 15 bold",width=10)
Cost_of_Drinks_Entry=Entry(Total_Frame,textvariable=t_cake,font="American 15 bold",width=10)
Cost_of_Non_veg_Food_Entry=Entry(Total_Frame,textvariable=t_food,font="American 15 bold",width=10)
Sub_Total_Entry=Entry(Total_Frame,textvariable=t_total,font="American 15 bold",width=10)
Service_Tax_Entry=Entry(Total_Frame,textvariable=t_service,font="American 15 bold",width=10)
Total_Cost_Entry=Entry(Total_Frame,textvariable=t_grand_total,font="American 15 bold",width=10)

Cost_of_Veg_Food.grid(row=0,column=0,sticky='w')
Cost_of_Drinks.grid(row=1,column=0,sticky='w')
Cost_of_Non_veg_Food.grid(row=2,column=0,sticky='w')

Cost_of_Veg_Food_Entry.grid(row=0,column=1,padx=60)
Cost_of_Drinks_Entry.grid(row=1,column=1,padx=60)
Cost_of_Non_veg_Food_Entry.grid(row=2,column=1,padx=60)


Sub_Total.grid(row=0,column=2,padx=62,sticky='w')
Service_Tax.grid(row=1,column=2,padx=62,sticky='w')
Total_Cost.grid(row=2,column=2,padx=62,sticky='w')

Sub_Total_Entry.grid(row=0,column=3)
Service_Tax_Entry.grid(row=1,column=3)
Total_Cost_Entry.grid(row=2,column=3)


Answer=Entry(Calculator_frame,width=29,font="American 20 bold",state='disabled',textvariable=calc_answer_txt,borderwidth=7,relief=RIDGE)
Answer.grid(row=0,column=0,columnspan=5)


def clear():
    global operator
    operator=''
    Answer.configure(state='normal')
    Answer.delete(0,END)
    Answer.configure(state='disabled')


def answer():
    global operator
    try:
        result=str(eval(operator))
        Answer.configure(state='normal')
        Answer.delete(0,END)
        Answer.insert(0,result)
        operator=''
        Answer.configure(state='disabled')
    except:
        Answer.configure(state='normal')
        Answer.delete(0,END)
        Answer.insert(0,"ERROR")
        Answer.configure(state='disabled')
    


Button(Calculator_frame,bg="#e60000",fg="white",text="7",width=12,borderwidth=4,height=1,font="Ameican 10 bold",command=lambda:buttonClick('7')).grid(row=1,column=0)
Button(Calculator_frame,bg="#e60000",fg="white",text="8",width=12,borderwidth=4,height=1,font="Ameican 10 bold",command=lambda:buttonClick('8')).grid(row=1,column=1,sticky='w')
Button(Calculator_frame,bg="#e60000",fg="white",text="9",width=12,borderwidth=4,height=1,font="Ameican 10 bold",command=lambda:buttonClick('9')).grid(row=1,column=2,sticky='w')
Button(Calculator_frame,bg="#e60000",fg="white",text="+",width=13,borderwidth=4,height=1,font="Ameican 10 bold",command=lambda:buttonClick('+')).grid(row=1,column=3,sticky='w')


Button(Calculator_frame,bg="#e60000",fg="white",text="4",width=12,borderwidth=4,height=1,font="Ameican 10 bold",command=lambda:buttonClick('4')).grid(row=2,column=0)
Button(Calculator_frame,bg="white",fg="#e60000",text="5",width=12,borderwidth=4,height=1,font="Ameican 10 bold",command=lambda:buttonClick('5')).grid(row=2,column=1,sticky='w')
Button(Calculator_frame,bg="white",fg="#e60000",text="6",width=12,borderwidth=4,height=1,font="Ameican 10 bold",command=lambda:buttonClick('6')).grid(row=2,column=2,sticky='w')
Button(Calculator_frame,bg="#e60000",fg="white",text="-",width=13,borderwidth=4,height=1,font="Ameican 10 bold",command=lambda:buttonClick('-')).grid(row=2,column=3,sticky='w')

Button(Calculator_frame,bg="#e60000",fg="white",text="1",width=12,borderwidth=4,height=1,font="Ameican 10 bold",command=lambda:buttonClick('1')).grid(row=3,column=0)
Button(Calculator_frame,bg="white",fg="#e60000",text="2",width=12,borderwidth=4,height=1,font="Ameican 10 bold",command=lambda:buttonClick('2')).grid(row=3,column=1,sticky='w')
Button(Calculator_frame,bg="white",fg="#e60000",text="3",width=12,borderwidth=4,height=1,font="Ameican 10 bold",command=lambda:buttonClick('3')).grid(row=3,column=2,sticky='w')
Button(Calculator_frame,bg="#e60000",fg="white",text="*",width=13,borderwidth=4,height=1,font="Ameican 10 bold",command=lambda:buttonClick('*')).grid(row=3,column=3,sticky='w')

Button(Calculator_frame,bg="#e60000",fg="white",text="Ans",width=12,borderwidth=4,height=1,font="Ameican 10 bold",command=answer).grid(row=4,column=0)
Button(Calculator_frame,bg="#e60000",fg="white",text="Clear",width=12,borderwidth=4,height=1,font="Ameican 10 bold",command=clear).grid(row=4,column=1,sticky='w')
Button(Calculator_frame,bg="#e60000",fg="white",text="0",width=12,borderwidth=4,height=1,font="Ameican 10 bold",command=lambda:buttonClick('0')).grid(row=4,column=2,sticky='w')
Button(Calculator_frame,bg="#e60000",fg="white",text="/",width=13,borderwidth=4,height=1,font="Ameican 10 bold",command=lambda:buttonClick('/')).grid(row=4,column=3,sticky='w')


Textarea=Text(Bill_frame,font="Monospace 14 bold",height=15,width=38,borderwidth=3)
scrollbar=Scrollbar(Bill_frame,orient='vertical',command=Textarea.yview)
scrollbar.grid(row=0,column=1,sticky=W,ipady=142)
Textarea['yscrollcommand']=scrollbar.set

Textarea.grid(row=0,column=0,sticky=N)


Button(Button_Frame,text="Submit",height=2,width=12,bg="#e60000",fg='white',font="American 9 bold",command=submit).grid(row=0,column=0)
Button(Button_Frame,text="Receipt",height=2,width=11,bg="#e60000",font="American 9 bold",fg="white",command=receipt).grid(row=0,column=1)
Button(Button_Frame,text="Save",height=2,width=11,bg="#e60000",font="American 9 bold",fg="white",command=save_fn).grid(row=0,column=2)
Button(Button_Frame,text=" Send",height=2,width=11,bg="#e60000",font="American 9 bold",fg="white",command=send).grid(row=0,column=3)
Button(Button_Frame,text="Reset",height=2,width=11,bg="#e60000",font="American 9 bold",fg="white",command=reset).grid(row=0,column=4)


Title_Frame.grid(row=0,column=0,columnspan=2,sticky=W)
Menu_frame.grid(row=1,sticky=W)
Veg_Food_Frame.grid(row=0,column=0)
Drink_frame.grid(row=0,column=1)
Non_Veg_Food_Frame.grid(row=0,column=2)
Total_Frame.grid(row=2,column=0,sticky=W)
Calc_Bill_Frame.grid(row=1,column=1,sticky=W,rowspan=2)
Calculator_frame.grid(row=0,column=0,sticky='w')
Bill_frame.grid(row=1,column=0,sticky='n')
Button_Frame.grid(row=2,column=0,stick="n")


#calculator
operator=''
def buttonClick(numbers):
    global operator
    Answer.configure(state='normal')
    operator=operator+numbers
    Answer.delete(0,END)
    Answer.insert(END,operator)
    Answer.configure(state='disabled')
    
root.mainloop()